import datetime 
def get_datetime():
    dt1 = datetime.datetime.now()
    return dt1.strftime("%d %B, %Y")
monthstr = get_datetime()
urlapi= '/data/movieurl'
key='/data/apikey'
ERRORNOTIFICATIONARN = '/data/errorarn'
SUCCESSNOTIFICATIONARN='/data/successarn'
COMPONENT_NAME = 'DL_DATA_EXTRA'
ERROR_MSG = f'NEED ATTENTION WIKI ERROR ON {monthstr} **'
SUCCESS_MSG = f'SUCCESSFULLY EXTRACTED  FILES FOR {monthstr}*'
SUCCESS_DESCRIPTION='SUCCESS'
ENVIRONMENT = '/data/environment'